import React from "react";
import ReactDOM from "react-dom/client";
import FantamatrimonioApp from "./FantamatrimonioApp.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <FantamatrimonioApp />
  </React.StrictMode>
);
